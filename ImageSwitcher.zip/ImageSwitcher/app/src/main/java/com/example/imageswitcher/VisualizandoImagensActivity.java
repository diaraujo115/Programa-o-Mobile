package com.example.imageswitcher;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import android.view.*;


import android.os.Bundle;

public class VisualizandoImagensActivity extends AppCompatActivity {

    ImageSwitcher imgFoto, imgSobre;
    Button btanterior, btproximo;

    int indice = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizando_imagens);

        Animation in = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);

        Animation out = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);


        btanterior = (Button) findViewById(R.id.btanterior);
        btproximo = (Button) findViewById(R.id.btproximo);

        imgFoto = (ImageSwitcher) findViewById(R.id.imgFoto);

        imgFoto.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_XY);
                myView.setLayoutParams(new ImageSwitcher.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                        ActionBar.LayoutParams.WRAP_CONTENT));
                return myView;
            }
        });
        imgSobre = (ImageSwitcher) findViewById(R.id.imgSobre);

        imgSobre.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView myView = new ImageView(getApplicationContext());
                myView.setScaleType(ImageView.ScaleType.FIT_XY);
                myView.setLayoutParams(new ImageSwitcher.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                        ActionBar.LayoutParams.WRAP_CONTENT));
                return myView;
            }
        });

        imgFoto.setImageResource(R.drawable.foto_deadpool);
        imgFoto.setInAnimation(in);
        imgFoto.setOutAnimation(out);
        
        imgSobre.setImageResource(R.drawable.frase_sobre_deadpool);
        imgSobre.setInAnimation(in);
        imgSobre.setOutAnimation(out);

        btanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(indice >1)
                {
                    indice--;
                    mostrarInfo();
                }
            }
        });

        btproximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(indice<3)
                {
                    indice++;
                    mostrarInfo();
                }
            }
        });
    }
    public void mostrarInfo(){
        switch (indice){
            case 1: {
                imgFoto.setImageResource(R.drawable.foto_deadpool);
                imgSobre.setImageResource(R.drawable.frase_sobre_deadpool);
            }break;
            case 2:{
                imgFoto.setImageResource(R.drawable.foto_colossus);
                imgSobre.setImageResource(R.drawable.frase_sobre_colossus);
            }break;
            case 3: {
                imgFoto.setImageResource(R.drawable.foto_megasonico);
                imgSobre.setImageResource(R.drawable.frase_sobre_megasonico);
            }break;
        }
    }
}