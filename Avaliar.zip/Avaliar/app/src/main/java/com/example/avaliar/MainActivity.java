package com.example.avaliar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtStatus;
    RatingBar rtbVotacao;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtStatus = (TextView)findViewById(R.id.txtStatus);
        rtbVotacao = (RatingBar) findViewById(R.id.rtbVotacao);


        rtbVotacao.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                // Define o status com base na nota
                if (v == 1)
                    txtStatus.setText("Status: Ruim");
                else if (v == 2)
                    txtStatus.setText("Status: Regular");
                else if (v == 3)
                    txtStatus.setText("Status: Bom");
                else if (v == 4)
                    txtStatus.setText("Status: Ótimo");
                else if (v == 5)
                    txtStatus.setText("Status: Excelente");

                // Exibe o alerta de confirmação
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Confirmação");
                builder.setMessage("Deseja enviar avaliação? - "+ txtStatus.getText());

                builder.setPositiveButton("SIM", (dialog, which) -> {
                    txtStatus.setText("ENVIADO");
                });

                builder.setNegativeButton("NÃO", (dialog, which) -> {
                    rtbVotacao.setRating(0); // Reseta a avaliação
                    txtStatus.setText("Status: ");
                });

                builder.show();
            }
        });
    }
}
